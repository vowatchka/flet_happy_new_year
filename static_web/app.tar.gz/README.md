# flet_happy_new_year
Анимированное поздравление с Новым Годом на Flet
