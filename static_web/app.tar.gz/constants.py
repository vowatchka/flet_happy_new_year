"""Модуль констант"""

OFFSET_BOTTOM = 6
